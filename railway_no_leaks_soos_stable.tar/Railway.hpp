//
// Created by skaysoul on 3/17/22.
//

#ifndef SO2_PROJECT_RAILWAY_H
#define SO2_PROJECT_RAILWAY_H

#include <ncurses.h>
#include <unistd.h>
#include <iostream>
#include <vector>
#include <string>
#include <semaphore.h>
#include <memory>

using namespace std;
struct Char
{
    char c;
    WINDOW *win;
    Char(char c, WINDOW *win)
        : c(c), win(win)
    {
    }

    char getC() const
    {
        return c;
    }
};

struct Position
{
    size_t pos;
    Position(size_t i) : pos(i)
    {
    }
};

struct WindowData
{
    int h1;
    int w1;
    int sy1;
    int sx1;
    int h2;
    int w2;
    int sy2;
    int sx2;

    WindowData(int h1, int w1, int sx1, int sy1, int h2, int w2, int sx2, int sy2)
        : h1(h1), w1(w1), sx1(sx1), sy1(sy1), h2(h2), w2(w2), sx2(sx2), sy2(sy2)
    {
    }
};

struct Train
{
    int startposx;
    int startposy;
    int currentposx;
    int currentposy;
    long sleeptime;
    int prevposx;
    int prevposy;
    const char *name;

    Train(int startposx, int startposy, const char *trainName)
        : startposx(startposx),
          startposy(startposy),
          name(trainName),
          currentposx(startposx),
          currentposy(startposy),
          prevposx(currentposx),
          prevposy(currentposy),
          sleeptime(rand() % 800000 + 100000) {
    }
};

struct Data
{
    std::unique_ptr<Train> trainData;
    std::unique_ptr<WindowData> windowData;
    Data() = default;
    Data(Train* trainData, WindowData *windowData)
    :trainData(trainData), windowData(windowData)
    {
    }
};

class Railway
{
public:
    Railway() = default;
    static void startsimulation();

private:
    static bool isEndOfSimulation;

    static std::vector<std::unique_ptr<Data>> way1trains;
    static std::vector<std::unique_ptr<Data>> way2trains;

    static const int way1trains_size = 10;
    static const int way2trains_size = 3;

    static WINDOW* createView();
    static void destroyView(WINDOW *railway, const int exitCode);
    
    static void *endSimulation(void *arg);
    
    static void *createRailway(void *arg);
    static void initializeTrains(WindowData *windowData);
    static void *updateWays(void *arg);
    
    static void printWay(WINDOW *win, WindowData *windata);
    static void moveTrain(const int way, WINDOW *win, const int posx, const int posy, const char *train_name);
    static void printSharp(WINDOW *win, int posx, int posy);

    static void *updatePositionWay1(void *arg);
    static void *updatePositionWay2(void *arg);

    static int w1_cs1_counter;
    static int w1_cs2_counter;
    static int w2_cs1_counter;
    static int w2_cs2_counter;

    static pthread_mutex_t w1_cs1_count_mutex;
    static pthread_mutex_t w1_cs2_count_mutex;
    static pthread_mutex_t w2_cs1_count_mutex;
    static pthread_mutex_t w2_cs2_count_mutex;

    static pthread_mutex_t w1_cs1_lock_mutex;
    static pthread_mutex_t w1_cs2_lock_mutex;
    static pthread_mutex_t w2_cs1_lock_mutex;
    static pthread_mutex_t w2_cs2_lock_mutex;

    static pthread_cond_t w1_cs1_condition;
    static pthread_cond_t w1_cs2_condition;
    static pthread_cond_t w2_cs1_condition;
    static pthread_cond_t w2_cs2_condition;

    static void mutex_init();
    static void mutex_delete();

};

#endif // SO2_PROJECT_RAILWAY_H
