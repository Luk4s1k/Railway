//
// Created by skaysoul on 3/17/22.
//

#include "Railway.hpp"
#include <pthread.h>
#include <semaphore.h>

bool Railway::isEndOfSimulation = false;

std::vector<std::unique_ptr<Data>> Railway::way1trains(way1trains_size);
std::vector<std::unique_ptr<Data>> Railway::way2trains(way2trains_size);

int Railway::w1_cs1_counter = 0;
int Railway::w1_cs2_counter = 0;
int Railway::w2_cs1_counter = 0;
int Railway::w2_cs2_counter = 0;

pthread_mutex_t Railway::w1_cs1_lock_mutex;
pthread_mutex_t Railway::w1_cs2_lock_mutex;
pthread_mutex_t Railway::w2_cs1_lock_mutex;
pthread_mutex_t Railway::w2_cs2_lock_mutex;

pthread_cond_t Railway::w1_cs1_condition;
pthread_cond_t Railway::w1_cs2_condition;
pthread_cond_t Railway::w2_cs1_condition;
pthread_cond_t Railway::w2_cs2_condition;

void Railway::mutex_init(void)
{
    pthread_mutex_init(&w1_cs1_lock_mutex, NULL);
    pthread_mutex_init(&w1_cs2_lock_mutex, NULL);
    pthread_mutex_init(&w2_cs1_lock_mutex, NULL);
    pthread_mutex_init(&w2_cs2_lock_mutex, NULL);

    pthread_cond_init(&w1_cs1_condition, NULL);
    pthread_cond_init(&w1_cs2_condition, NULL);
    pthread_cond_init(&w2_cs1_condition, NULL);
    pthread_cond_init(&w2_cs2_condition, NULL);
}

void Railway::mutex_delete(void)
{
    pthread_mutex_destroy(&w1_cs1_lock_mutex);
    pthread_mutex_destroy(&w1_cs2_lock_mutex);
    pthread_mutex_destroy(&w2_cs1_lock_mutex);
    pthread_mutex_destroy(&w2_cs2_lock_mutex);

    pthread_cond_destroy(&w1_cs1_condition);
    pthread_cond_destroy(&w1_cs2_condition);
    pthread_cond_destroy(&w2_cs1_condition);
    pthread_cond_destroy(&w2_cs2_condition);
}

void Railway::startsimulation()
{
    mutex_init();

    WindowData *windowData = new WindowData(5, 40, 10, 10, 15, 15, 23, 5);

    pthread_t printer_thread;
    if (pthread_create(&printer_thread, NULL, createRailway, windowData) != 0)
    {
        std::cout << "Error:unable to create thread" << std::endl;
        delete windowData;
        exit(-1);
    }

    int printer_thread_join = pthread_join(printer_thread, NULL);

    if (printer_thread_join)
    {
        std::cout << "Error:unable to join thread," << printer_thread_join << std::endl;
        delete windowData;
        exit(-1);
    }

    mutex_delete();
}

WINDOW *Railway::createView()
{
    initscr();
    // noecho();

    if (has_colors())
    {
        // Enable color mode
        start_color();
        // Define color pairs (foreground color, background color)
        init_pair(1, COLOR_RED, COLOR_BLACK);
        init_pair(2, COLOR_GREEN, COLOR_BLACK);
    }
    refresh();
    WINDOW *railway = newwin(25, 60, 0, 0);
    // refresh();
    curs_set(0);
    wborder(railway, '|', '|', '-', '-', '+', '+', '+', '+');

    return railway;
}

void Railway::destroyView(WINDOW *railway, const int exitCode)
{
    endwin();
    delwin(railway);
    exit(exitCode);
}

void *Railway::createRailway(void *arg)
{

    pthread_t exit_thread;
    WindowData *windata = static_cast<WindowData *>(arg);
    WINDOW *railway = createView();
    Char *c = new Char('e', railway);

    if (pthread_create(&exit_thread, NULL, endSimulation, c) != 0)
    {
        std::cout << "Error:unable to create thread" << std::endl;
        endwin();
        delwin(railway);
        exit(-1);
    }

    printWay(railway, windata);

    initializeTrains(windata);

    pthread_t update_thread;

    if (pthread_create(&update_thread, NULL, updateWays, railway) != 0)
    {
        std::cout << "Error:unable to create update thread" << std::endl;
        destroyView(railway, -1);
    }

    pthread_t way1threads[way1trains_size];
    pthread_t way2threads[way2trains_size];

    for (int i = 0; i < way2trains_size; i++)
    {
        int thread;
        Position *position = new Position(i);
        if (pthread_create(&way1threads[i], NULL, updatePositionWay2, position) != 0)
        {
            std::cout << "Error:unable to create thread" << std::endl;
            destroyView(railway, -1);
        }
        usleep(random() % 500000 + 100000);
    }

    for (int i = 0; i < way1trains_size; i++)
    {
        int thread;
        Position *position = new Position(i);
        if (pthread_create(&way1threads[i], NULL, updatePositionWay1, position) != 0)
        {
            std::cout << "Error:unable to create thread" << std::endl;
            destroyView(railway, -1);
        }
        usleep(random() % 1000000 + 500000);
    }

    while (true)
    {
        if (isEndOfSimulation)
        {
            for (int i = 0; i < way1trains_size; i++)
            {
                if (pthread_join(way1threads[i], NULL) != 0)
                {
                    std::cout << "Error:unable to join thread" << std::endl;
                    destroyView(railway, -1);
                }
            }

            for (int i = 0; i < way2trains_size; i++)
            {
                if (pthread_join(way2threads[i], NULL) != 0)
                {
                    std::cout << "Error:unable to join thread" << std::endl;
                    destroyView(railway, -1);
                }
            }

            if (pthread_join(exit_thread, NULL) != 0)
            {
                std::cout << "Error:unable to join thread" << std::endl;
                destroyView(railway, -1);
            }

            if (pthread_join(update_thread, NULL) != 0)
            {
                std::cout << "Error:unable to join thread" << std::endl;
                destroyView(railway, -1);
            }
            endwin();
            delwin(railway);
            pthread_exit(NULL);
        }
    }
}

void Railway::moveTrain(const int way, WINDOW *win, const int posx, const int posy, const char *train_name)
{
    wattron(win, COLOR_PAIR(way)); // Use color pair 1 (red text on black background)
    mvwprintw(win, posy, posx, train_name);
    wattroff(win, COLOR_PAIR(way));
}

void Railway::printSharp(WINDOW *win, int posx, int posy)
{
    mvwprintw(win, posy, posx, " ");
}

void *Railway::updateWays(void *arg)
{
    WINDOW *win = ((WINDOW *)arg);
    while (true)
    {
        for (int i = 0; i < way1trains_size; i++)
        {
            moveTrain(1, win, way1trains.at(i)->trainData->currentposx, way1trains.at(i)->trainData->currentposy, way1trains.at(i)->trainData->name);
            printSharp(win, way1trains.at(i)->trainData->prevposx, way1trains.at(i)->trainData->prevposy);
        }
        for (int i = 0; i < way2trains_size; i++)
        {
            moveTrain(2, win, way2trains.at(i)->trainData->currentposx, way2trains.at(i)->trainData->currentposy, way2trains.at(i)->trainData->name);
            printSharp(win, way2trains.at(i)->trainData->prevposx, way2trains.at(i)->trainData->prevposy);
        }
        wrefresh(win);
        usleep(20000);
        if (isEndOfSimulation)
        {
            pthread_exit(NULL);
        }
    }
}

void Railway::printWay(WINDOW *win, WindowData *windata)
{
    for (int i = 0; i <= windata->w1; i++)
    {
        if (windata->sx1 - 1 + i != windata->sx2 && windata->sx1 - 1 + i != windata->sx2 + windata->w2 - 2)
        {
            mvwprintw(win, windata->sy1 - 1, windata->sx1 - 1 + i, "#");
            mvwprintw(win, windata->sy1 + windata->h1 + 1, windata->sx1 - 1 + i, "#");
        }
        wrefresh(win);
    }
    for (int i = 0; i < windata->w1 - 3; i++)
    {
        if (windata->sx1 + 1 + i != windata->sx2 && windata->sx1 + 1 + i != windata->sx2 + windata->w2 - 2)
        {
            mvwprintw(win, windata->sy1 + windata->h1 - 1, windata->sx1 + i + 1, "#");
            mvwprintw(win, windata->sy1 + 1, windata->sx1 + i + 1, "#");
        }
        wrefresh(win);
    }
    for (int i = 0; i <= windata->h1; i++)
    {
        mvwprintw(win, windata->sy1 + i, windata->sx1 - 1, "#");
        mvwprintw(win, windata->sy1 + i, windata->sx1 + windata->w1 - 1, "#");
        wrefresh(win);
    }
    for (int i = 0; i <= windata->h1 - 3; i++)
    {
        mvwprintw(win, windata->sy1 + i + 1, windata->sx1 + 1, "#");
        mvwprintw(win, windata->sy1 + i + 1, windata->sx1 + windata->w1 - 3, "#");
        wrefresh(win);
    }
    // r2
    for (int i = 0; i <= windata->w2; i++)
    {
        mvwprintw(win, windata->sy2 - 1, windata->sx2 - 1 + i, "#");
        mvwprintw(win, windata->sy2 + windata->h2 + 1, windata->sx2 - 1 + i, "#");
        wrefresh(win);
    }
    for (int i = 0; i < windata->w2 - 3; i++)
    {
        mvwprintw(win, windata->sy2 + windata->h2 - 1, windata->sx2 + i + 1, "#");
        mvwprintw(win, windata->sy2 + 1, windata->sx2 + i + 1, "#");
        wrefresh(win);
    }

    for (int i = 0; i <= windata->h2; i++)
    {
        if (windata->sy2 + i != windata->sy1 && windata->sy2 + i != windata->sy1 + windata->h1)
        {
            mvwprintw(win, windata->sy2 + i, windata->sx2 - 1, "#");
            mvwprintw(win, windata->sy2 + i, windata->sx2 + windata->w2 - 1, "#");
        }
        wrefresh(win);
    }
    for (int i = 0; i <= windata->h2 - 3; i++)
    {
        if (windata->sy2 + i + 1 != windata->sy1 && windata->sy2 + i + 1 != windata->sy1 + windata->h1)
        {
            mvwprintw(win, windata->sy2 + i + 1, windata->sx2 + 1, "#");
            mvwprintw(win, windata->sy2 + i + 1, windata->sx2 + windata->w2 - 3, "#");
        }
        wrefresh(win);
    }
}

void *Railway::updatePositionWay1(void *arg)
{
    Position *position = ((Position *)arg);
    int condlock1 = way1trains.at(position->pos)->windowData->sx2 - 1 - way1trains.at(position->pos)->windowData->sx1;
    int condlock2 = way1trains.at(position->pos)->windowData->w1 - 1 + way1trains.at(position->pos)->windowData->h1 - 1 +
                    way1trains.at(position->pos)->windowData->w1 - 1 - (way1trains[position->pos]->windowData->sx2 - 1 - way1trains.at(position->pos)->windowData->sx1) - way1trains.at(position->pos)->windowData->w2 - 1;
    int condunlock1 = way1trains.at(position->pos)->windowData->sx2 - 1 - way1trains.at(position->pos)->windowData->sx1 + way1trains.at(position->pos)->windowData->w2;
    int condunlock2 = way1trains.at(position->pos)->windowData->w1 - 1 + way1trains.at(position->pos)->windowData->h1 +
                      way1trains.at(position->pos)->windowData->w1 - 2 - (way1trains[position->pos]->windowData->sx2 - 1 - way1trains.at(position->pos)->windowData->sx1);
    for (int j = 0; j < 4; j++)
    {
        for (int i = 0; i < way1trains.at(position->pos)->windowData->h1 * 2 + way1trains.at(position->pos)->windowData->w1 * 2 - 2; i++)
        {
            if (i == condlock1)
            {
                pthread_mutex_lock(&w1_cs1_lock_mutex);
                while (w1_cs1_counter > 1)
                {
                    pthread_cond_wait(&w1_cs1_condition, &w1_cs1_lock_mutex);
                }
                pthread_mutex_unlock(&w1_cs1_lock_mutex);
                pthread_mutex_lock(&w1_cs1_lock_mutex);
                w1_cs1_counter++;
                pthread_mutex_unlock(&w1_cs1_lock_mutex);
            }

            if (i == condunlock1)
            {
                pthread_mutex_lock(&w1_cs1_lock_mutex);
                w1_cs1_counter--;
                pthread_mutex_unlock(&w1_cs1_lock_mutex);
                if (w1_cs1_counter < 2)
                {
                    pthread_cond_broadcast(&w1_cs1_condition);
                }
            }
            // cs2 lock
            if (i == condlock2)
            {
                pthread_mutex_lock(&w1_cs2_lock_mutex);
                while (w1_cs2_counter > 1)
                {
                    pthread_cond_wait(&w1_cs2_condition, &w1_cs2_lock_mutex);
                }
                pthread_mutex_unlock(&w1_cs2_lock_mutex);
                pthread_mutex_lock(&w1_cs2_lock_mutex);
                w1_cs2_counter++;
                pthread_mutex_unlock(&w1_cs2_lock_mutex);
            }

            if (i == condunlock2)
            {
                pthread_mutex_lock(&w1_cs2_lock_mutex);
                w1_cs2_counter--;
                pthread_mutex_unlock(&w1_cs2_lock_mutex);
                if (w1_cs2_counter < 2)
                {
                    pthread_cond_broadcast(&w1_cs2_condition);
                }
            }

            // up pos
            if (i < way1trains.at(position->pos)->windowData->w1 - 2)
            {
                way1trains.at(position->pos)->trainData->currentposx += 1;
                way1trains.at(position->pos)->trainData->prevposx = way1trains.at(position->pos)->trainData->currentposx - 1;
            }

            if (i == way1trains.at(position->pos)->windowData->w1 - 2)
            {
                way1trains.at(position->pos)->trainData->currentposy += 1;
                way1trains.at(position->pos)->trainData->prevposx = way1trains[position->pos]->trainData->currentposx;
            }
            // left pos
            if (i > way1trains.at(position->pos)->windowData->w1 - 2 && i < way1trains.at(position->pos)->windowData->w1 + way1trains.at(position->pos)->windowData->h1 - 2)
            {
                way1trains.at(position->pos)->trainData->currentposy += 1;
                way1trains.at(position->pos)->trainData->prevposy = way1trains.at(position->pos)->trainData->currentposy - 1;
            }
            if (i == way1trains.at(position->pos)->windowData->w1 + way1trains.at(position->pos)->windowData->h1 - 2)
            {
                way1trains.at(position->pos)->trainData->currentposx -= 1;
                way1trains.at(position->pos)->trainData->prevposy = way1trains[position->pos]->trainData->currentposy;
            }
            // down pos
            if (i > way1trains.at(position->pos)->windowData->w1 + way1trains.at(position->pos)->windowData->h1 - 2 && i <
                                                                                                                           way1trains.at(position->pos)->windowData->w1 + way1trains.at(position->pos)->windowData->h1 + way1trains.at(position->pos)->windowData->w1 - 4)
            {
                way1trains.at(position->pos)->trainData->currentposx -= 1;
                way1trains.at(position->pos)->trainData->prevposx = way1trains.at(position->pos)->trainData->currentposx + 1;
            }
            if (j != 2)
            {

                if (i == way1trains.at(position->pos)->windowData->w1 + way1trains.at(position->pos)->windowData->h1 + way1trains.at(position->pos)->windowData->w1 - 4)
                {
                    way1trains.at(position->pos)->trainData->currentposy -= 1;
                    way1trains.at(position->pos)->trainData->prevposx = way1trains[position->pos]->trainData->currentposx;
                }
                // right pos
                if (i > way1trains.at(position->pos)->windowData->w1 + way1trains.at(position->pos)->windowData->h1 + way1trains.at(position->pos)->windowData->w1 - 2)
                {
                    way1trains.at(position->pos)->trainData->currentposy -= 1;
                    way1trains.at(position->pos)->trainData->prevposy = way1trains.at(position->pos)->trainData->currentposy + 1;
                }
                if (i == way1trains.at(position->pos)->windowData->h1 * 2 + way1trains.at(position->pos)->windowData->w1 * 2 - 3)
                {
                    way1trains.at(position->pos)->trainData->prevposy = way1trains.at(position->pos)->trainData->currentposy;
                }
            }
            if (j == 2 && i > way1trains.at(position->pos)->windowData->w1 + way1trains.at(position->pos)->windowData->h1 + way1trains.at(position->pos)->windowData->w1 - 4)
            {
                way1trains.at(position->pos)->trainData->prevposx = way1trains[position->pos]->trainData->currentposx;
                way1trains.at(position->pos)->trainData->currentposy = 1000;
                way1trains.at(position->pos)->trainData->currentposx = 1000;
                pthread_exit(NULL);
            }
            usleep(way1trains[position->pos]->trainData->sleeptime);
        }
    }
    delete position;
    return nullptr;
}

void *Railway::updatePositionWay2(void *arg)
{
    Position *position = ((Position *)arg);
    int condlock1 = way1trains.at(position->pos)->windowData->w2 - 1 + (way1trains[position->pos]->windowData->sy1 - 1 - way1trains[position->pos]->windowData->sy2 - 1);

    int condlock2 = way1trains.at(position->pos)->windowData->w2 - 1 + way1trains.at(position->pos)->windowData->h2 - 1 +
                    way1trains.at(position->pos)->windowData->w2 - 1 + (way1trains[position->pos]->windowData->h2 - (way1trains[position->pos]->windowData->sy1 - way1trains[position->pos]->windowData->sy2) - way1trains.at(position->pos)->windowData->h1);
    int condunlock1 = way1trains.at(position->pos)->windowData->w2 - 1 + way1trains.at(position->pos)->windowData->h2 - (way1trains[position->pos]->windowData->sy1 - way1trains[position->pos]->windowData->sy2);
    int condunlock2 = way1trains.at(position->pos)->windowData->w2 - 1 + way1trains.at(position->pos)->windowData->h2 - 1 +
                      way1trains.at(position->pos)->windowData->w2 - 1 + (way1trains[position->pos]->windowData->h2 - (way1trains[position->pos]->windowData->sy1 - way1trains[position->pos]->windowData->sy2));
    while (true)
    {
        for (int i = 0; i < way2trains.at(position->pos)->windowData->h2 * 2 + way2trains.at(position->pos)->windowData->w2 * 2 - 2; i++)
        {
            // cs1 lock
            if (i == condlock1)
            {
                pthread_mutex_lock(&w2_cs1_lock_mutex);
                while (w2_cs1_counter > 1)
                {
                    pthread_cond_wait(&w2_cs1_condition, &w2_cs1_lock_mutex);
                }
                pthread_mutex_unlock(&w2_cs1_lock_mutex);
                pthread_mutex_lock(&w2_cs1_lock_mutex);
                w2_cs1_counter++;
                pthread_mutex_unlock(&w2_cs1_lock_mutex);
            }

            if (i == condunlock1)
            {
                pthread_mutex_lock(&w2_cs1_lock_mutex);
                w2_cs1_counter--;
                pthread_mutex_unlock(&w2_cs1_lock_mutex);
                if (w2_cs1_counter < 2)
                {
                    pthread_cond_broadcast(&w2_cs1_condition);
                }
            }
            // cs2 lock
            if (i == condlock2)
            {
                pthread_mutex_lock(&w2_cs2_lock_mutex);
                while (w2_cs2_counter > 1)
                {
                    pthread_cond_wait(&w2_cs2_condition, &w2_cs2_lock_mutex);
                }
                pthread_mutex_unlock(&w2_cs2_lock_mutex);
                pthread_mutex_lock(&w2_cs2_lock_mutex);
                w2_cs2_counter++;
                pthread_mutex_unlock(&w2_cs2_lock_mutex);
            }

            if (i == condunlock2)
            {
                pthread_mutex_lock(&w2_cs2_lock_mutex);
                w2_cs2_counter--;
                pthread_mutex_unlock(&w2_cs2_lock_mutex);
                if (w2_cs2_counter < 2)
                {
                    pthread_cond_broadcast(&w2_cs2_condition);
                }
            }

            if (i < way2trains.at(position->pos)->windowData->w2 - 2)
            {
                way2trains.at(position->pos)->trainData->currentposx += 1;
                way2trains.at(position->pos)->trainData->prevposx = way2trains.at(position->pos)->trainData->currentposx - 1;
            }
            if (i == way2trains.at(position->pos)->windowData->w2 - 2)
            {
                way2trains.at(position->pos)->trainData->currentposy += 1;
                way2trains.at(position->pos)->trainData->prevposx = way2trains.at(position->pos)->trainData->currentposx;
            }
            if (i > way2trains.at(position->pos)->windowData->w2 - 2 &&
                i < way2trains.at(position->pos)->windowData->w2 + way2trains.at(position->pos)->windowData->h2 - 2)
            {
                way2trains.at(position->pos)->trainData->currentposy += 1;
                way2trains.at(position->pos)->trainData->prevposy = way2trains.at(position->pos)->trainData->currentposy - 1;
            }
            if (i == way2trains.at(position->pos)->windowData->w2 + way2trains.at(position->pos)->windowData->h2 - 2)
            {
                way2trains.at(position->pos)->trainData->currentposx -= 1;
                way2trains.at(position->pos)->trainData->prevposy = way2trains.at(position->pos)->trainData->currentposy;
            }
            if (i > way2trains.at(position->pos)->windowData->w2 + way2trains.at(position->pos)->windowData->h2 - 2 && i <
                                                                                                                           way2trains.at(position->pos)->windowData->w2 + way2trains.at(position->pos)->windowData->h2 +
                                                                                                                               way1trains.at(position->pos)->windowData->w2 - 4)
            {
                way2trains.at(position->pos)->trainData->currentposx -= 1;
                way2trains.at(position->pos)->trainData->prevposx = way2trains.at(position->pos)->trainData->currentposx + 1;
            }
            if (i == way2trains.at(position->pos)->windowData->w2 + way2trains.at(position->pos)->windowData->h2 +
                         way2trains.at(position->pos)->windowData->w2 - 4)
            {
                way2trains.at(position->pos)->trainData->currentposy -= 1;
                way2trains.at(position->pos)->trainData->prevposx = way2trains.at(position->pos)->trainData->currentposx;
            }
            if (i > way2trains.at(position->pos)->windowData->w2 + way2trains.at(position->pos)->windowData->h2 +
                        way2trains.at(position->pos)->windowData->w2 - 2)
            {
                way2trains.at(position->pos)->trainData->currentposy -= 1;
                way2trains.at(position->pos)->trainData->prevposy = way2trains.at(position->pos)->trainData->currentposy + 1;
            }
            if (i == way2trains.at(position->pos)->windowData->h2 * 2 + way2trains.at(position->pos)->windowData->w2 * 2 - 3)
            {
                way2trains.at(position->pos)->trainData->prevposy = way2trains.at(position->pos)->trainData->currentposy;
            }
            if (isEndOfSimulation)
            {
                delete position;
                pthread_exit(NULL);
            }
            usleep(way1trains[position->pos]->trainData->sleeptime);
        }
    }
    delete position;
    return nullptr;
}

void Railway::initializeTrains(WindowData *windowData)
{
    const char *arrayChars[] = {"E", "F", "G", "L", "R", "D", "A", "V", "C", "S"};
    for (int i = 0; i < way1trains_size; i++)
    {
        long pos = random() % 10;
        Train *newTrain = new Train(windowData->sx1, windowData->sy1, arrayChars[pos]);
        way1trains[i] = std::make_unique<Data>(newTrain, windowData);
        if (i < way2trains_size)
        {
            Train *newTrain2 = new Train(windowData->sx2, windowData->sy2, arrayChars[pos]);
            way2trains[i] = std::make_unique<Data>(newTrain2, windowData);
        }
    }
}

void *Railway::endSimulation(void *arg)
{
    Char *c = static_cast<Char *>(arg);
    char x;
    do
    {
        x = getch();
    } while (x != c->getC());
    isEndOfSimulation = true;

    pthread_mutex_lock(&w1_cs1_lock_mutex);
    pthread_cond_broadcast(&w1_cs1_condition);
    pthread_mutex_unlock(&w1_cs1_lock_mutex);

    pthread_mutex_lock(&w1_cs2_lock_mutex);
    pthread_cond_broadcast(&w1_cs2_condition);
    pthread_mutex_unlock(&w1_cs2_lock_mutex);

    pthread_mutex_lock(&w2_cs1_lock_mutex);
    pthread_cond_broadcast(&w2_cs1_condition);
    pthread_mutex_unlock(&w2_cs1_lock_mutex);

    pthread_mutex_lock(&w2_cs2_lock_mutex);
    pthread_cond_broadcast(&w2_cs2_condition);
    pthread_mutex_unlock(&w2_cs2_lock_mutex);

    delete c;
    pthread_exit(NULL);
}