//
// Created by skaysoul on 3/17/22.
//
// Opis zadania:
// Pomiedzy skrzyzowaniami moga znajdowac sie tylko 2 pojazdy
//

#include "Railway.hpp"


int main(){
    std::unique_ptr<Railway> rw = std::make_unique<Railway>();
    rw->startsimulation();
    return 0;
}
